const ProductsSearch = () =>{
    return(
        <div className="productsSearchContainer">
            
        </div>
    )
}
export default ProductsSearch; 