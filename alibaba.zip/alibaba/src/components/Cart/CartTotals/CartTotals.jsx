const CartTotals = () => {
    return(<div></div>)
}
export default CartTotals