const EmptyCart = () => {
    return(<div></div>)
}
export default EmptyCart