const CartItem = () =>{
    return(
        <div>
            <span>CartItem</span>
        </div>
    )
}
export default CartItem