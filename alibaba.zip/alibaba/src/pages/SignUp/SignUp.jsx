const SignUp = () => {
    return(
        <div>
            signUp
        </div>
    )
}
export default SignUp