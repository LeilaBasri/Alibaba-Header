import './ShopCategory.css'
const ShopCategory = () =>{
    return(
        <div></div>
    )
}
export default ShopCategory